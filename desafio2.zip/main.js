let NombreProducto = "Huevos"
let PrecioUnitario = 4
let CantidadDeseada = prompt("¿Cuál es la cantidad deseada?")

let PrecioTotal = PrecioUnitario * CantidadDeseada
alert("El precio total de su compra es: " + PrecioTotal)