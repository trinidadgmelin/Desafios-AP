let NombreProducto="Vinilo"
let PrecioUnitario= 6000

let CantidadDeseada= prompt("Ingrese la cantidad que desea de este producto:")
let Total= PrecioUnitario * CantidadDeseada
let Descuento10= Total * 0.1

if(CantidadDeseada < 5){
    alert("Compra efectuada (total: " + Total + "). Gracias por tu compra.")
}
else if(CantidadDeseada => 5){
    alert("Obtuviste un 10% de descuento! (total: " + Descuento10 + "). Gracias por tu compra.")
}